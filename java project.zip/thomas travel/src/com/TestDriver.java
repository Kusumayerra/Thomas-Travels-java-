package com;

import java.util.ArrayList;

public class TestDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Travel t=new Travel();
    Driver d1=new Driver("car",1796,"kusuma",17.36);
    Driver d2=new Driver("lorry",1705,"suma",55.30);
    Driver d3=new Driver("car",8996,"uma",7.60);
    Driver d4=new Driver("cycle",5596,"ma",5.16);
System.out.println("checking the mentioned category is equal or not ? ");
    boolean response=t.isCarDriver(d1);
    System.out.println(response+" for the is car");
    ArrayList<Driver> driverList=new ArrayList<Driver>();
    driverList.add(d1);
    driverList.add(d2);
    driverList.add(d3);
    driverList.add(d4);
 System.out.println("getting a drivename , category and speed by the driverId ! ");
    String response2=t.RetrivedbyDriverId(driverList,5596);
    System.out.println(response2);
    int response3=t.RetriveCountOfDriver(driverList,"car");
    System.out.println(response3 +" is the category count ");
    ArrayList<Driver> response4=t.RetriveDriver(driverList, "car");
    System.out.println(" drivers and their category");
    for(Driver driver:response4)
    	System.out.println("name : "+driver.getDriverName()+","+" category :"+driver.getCategory());
	Driver maxDriver=t.RetriveMaxDistanceTravelledDriver(driverList);
	if(maxDriver!=null) {
		System.out.println("driver with maximum distance is : "+maxDriver.getDriverName()+"("+maxDriver.getTotalDistance()+"KM)");
	}
	}

}
