package com;

import java.util.ArrayList;

public class Travel {
	public boolean isCarDriver(Driver driver) {
		return driver.getCategory().equalsIgnoreCase("car");
	}
	public String RetrivedbyDriverId(ArrayList<Driver>driverList, int driverId) {
		
		for(Driver driver : driverList) {
			if(driver.getDriverId()==driverId) {
		return "driver name : "+driver.getDriverName()+"\n category : "+driver.getCategory()+"\n distance in KM : "+driver.getTotalDistance();
	}
		}
		return "No driver found with the Id";
	}
	public int RetriveCountOfDriver(ArrayList<Driver>driverList,String Category) {
		int count=0;
		for(Driver driver: driverList) {
			if(driver.getCategory().equalsIgnoreCase(Category)) {
				count++;
			}
		}
		return count;
	}
	public ArrayList<Driver> RetriveDriver(ArrayList<Driver>driverList,String Category){
		ArrayList<Driver> result=new ArrayList<>();
		for(Driver driver:driverList) {
			if(driver.getCategory().equalsIgnoreCase(Category)) {
		 result.add(driver);
	}
		}
		return result;
	}
	
	public Driver RetriveMaxDistanceTravelledDriver(ArrayList<Driver>driverList) {
		if(driverList==null || driverList.isEmpty()) {
			return null;
		}
		Driver maxDriver=driverList.get(0);
		for(Driver driver : driverList) {
			if(driver.getTotalDistance()>maxDriver.getTotalDistance()) {
				maxDriver=driver;
			}
		}
		return maxDriver;
	}

}
