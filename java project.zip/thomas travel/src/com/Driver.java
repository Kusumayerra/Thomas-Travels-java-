package com;

public class Driver {
	private String Category;
	private int driverId;
	private String driverName;
	private double TotalDistance;
	
	public Driver(String Category,int driverId,String driverName,double TotalDistance) {
		this.driverId=driverId;
		this.Category=Category;
		this.driverName=driverName;
		this.TotalDistance=TotalDistance;
	}
public int getDriverId() {
	return driverId;
}
public void setDriverId(int driverId) {
	this.driverId=driverId;
}
public String getCategory() {
	return Category;
}
public void setCategory(String Category) {
	this.Category=Category;
}
public String getDriverName() {
	return driverName;
}
public void setDriverName(String driverName) {
	this.driverName=driverName;
}
public double getTotalDistance() {
	return TotalDistance;
}
public void setTotalDistance(double TotalDistance) {
	this.TotalDistance=TotalDistance;
}
}
